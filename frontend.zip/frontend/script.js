const API = '/api';
const rupiah = n => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(Number(n) || 0);
const todayStr = () => new Date().toLocaleDateString('en-CA');
let packages = [];
let bookings = [];
let expenses = [];
let payments = [];

async function api(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Permintaan gagal. Periksa koneksi backend/Supabase.');
  return data;
}
function notify(message) { alert(message); }
function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
}
function showPage(id, btn) {
  document.querySelectorAll('.page').forEach(x => x.classList.remove('active'));
  document.getElementById(id)?.classList.add('active');
  document.querySelectorAll('.nav button').forEach(x => x.classList.remove('active'));
  if (btn) btn.classList.add('active');
  const titles = { dashboard:'Dashboard', packages:'Katalog Paket Makeup', bookings:'Booking & Jadwal', payments:'Pembayaran', expenses:'Pengeluaran', reports:'Laporan Keuangan' };
  document.getElementById('pageTitle').textContent = titles[id] || 'GlowUp MUA';
  renderAll();
}
function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }
function openBookingModal() {
  const select = document.getElementById('bPackage');
  select.innerHTML = packages.map(p => `<option value="${p.id}">${escapeHTML(p.name)} - ${rupiah(p.price)}</option>`).join('');
  document.getElementById('bDate').value = todayStr();
  document.getElementById('bDP').value = 0;
  openModal('bookingModal');
}
function openPackageModal() { document.getElementById('packageForm').reset(); openModal('packageModal'); }
function openExpenseModal() { document.getElementById('expenseForm').reset(); document.getElementById('eDate').value = todayStr(); openModal('expenseModal'); }

async function loadData() {
  try {
    const data = await api('/init');
    packages = data.packages || [];
    bookings = (data.bookings || []).map(b => ({
      ...b,
      customer: b.customer_name || b.customer?.name || 'Customer',
      packageId: b.package_id,
      packageName: b.package_name || b.package?.name || '-',
      date: b.booking_date,
      time: String(b.booking_time || '').slice(0,5),
      total: Number(b.total || 0),
      paid: Number(b.paid || 0)
    }));
    expenses = data.expenses || [];
    payments = data.payments || [];
    document.getElementById('today').textContent = new Date().toLocaleDateString('id-ID', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
    renderAll();
  } catch (err) {
    packages = []; bookings = []; expenses = []; payments = [];
    renderAll();
    notify(`Belum bisa mengambil data dari backend.\n${err.message}\n\nPastikan app.js berjalan dan konfigurasi Supabase sudah diatur.`);
  }
}

 document.getElementById('bookingForm').addEventListener('submit', async e => {
  e.preventDefault();
  const packageId = document.getElementById('bPackage').value;
  const selected = packages.find(p => String(p.id) === String(packageId));
  if (!selected) return notify('Pilih paket makeup terlebih dahulu.');
  const dp = Number(document.getElementById('bDP').value || 0);
  if (dp < 0 || dp > Number(selected.price)) return notify('DP tidak boleh kurang dari 0 atau melebihi harga paket.');
  const payload = {
    customer: document.getElementById('bCustomer').value.trim(), package_id: packageId,
    booking_date: document.getElementById('bDate').value, booking_time: document.getElementById('bTime').value,
    location: document.getElementById('bLocation').value.trim(), dp,
    status: document.getElementById('bStatus').value, note: document.getElementById('bNote').value.trim()
  };
  try { await api('/bookings', { method:'POST', body:JSON.stringify(payload) }); closeModal('bookingModal'); e.target.reset(); await loadData(); notify('Booking berhasil disimpan.'); }
  catch (err) { notify(`Booking gagal disimpan: ${err.message}`); }
});

document.getElementById('packageForm').addEventListener('submit', async e => {
  e.preventDefault();
  const payload = { name:document.getElementById('pName').value.trim(), price:Number(document.getElementById('pPrice').value), facilities:document.getElementById('pFacilities').value.trim() || 'Makeup sesuai paket' };
  try { await api('/packages', { method:'POST', body:JSON.stringify(payload) }); closeModal('packageModal'); e.target.reset(); await loadData(); notify('Paket berhasil ditambahkan.'); }
  catch (err) { notify(`Paket gagal ditambahkan: ${err.message}`); }
});

document.getElementById('expenseForm').addEventListener('submit', async e => {
  e.preventDefault();
  const payload = { date:document.getElementById('eDate').value, category:document.getElementById('eCategory').value, description:document.getElementById('eDesc').value.trim(), amount:Number(document.getElementById('eAmount').value) };
  try { await api('/expenses', { method:'POST', body:JSON.stringify(payload) }); closeModal('expenseModal'); e.target.reset(); await loadData(); notify('Pengeluaran berhasil dicatat.'); }
  catch (err) { notify(`Pengeluaran gagal dicatat: ${err.message}`); }
});

document.getElementById('paymentForm').addEventListener('submit', async e => {
  e.preventDefault();
  const booking = bookings[Number(document.getElementById('payIndex').value)];
  if (!booking) return notify('Data booking tidak ditemukan.');
  const payload = { booking_id:booking.id, amount:Number(document.getElementById('payAmount').value), method:document.getElementById('payMethod').value, date:todayStr() };
  try { await api('/payments', { method:'POST', body:JSON.stringify(payload) }); closeModal('paymentModal'); await loadData(); notify('Pembayaran berhasil dicatat.'); }
  catch (err) { notify(`Pembayaran gagal dicatat: ${err.message}`); }
});

function renderPackages() {
  document.getElementById('packageList').innerHTML = packages.length ? packages.map((p,i) => `<div class="package"><div class="package-top"><b>${escapeHTML(p.name)}</b><div style="font-size:12px;margin-top:5px">Paket Makeup</div></div><div class="package-body"><div class="price">${rupiah(p.price)}</div><ul>${String(p.facilities || '').split(',').map(x => `<li>${escapeHTML(x.trim())}</li>`).join('')}</ul><button class="btn btn-danger" style="margin-top:12px;width:100%" onclick="deletePackage(${i})">Hapus Paket</button></div></div>`).join('') : '<div class="empty">Belum ada paket makeup.</div>';
}
function renderBookings() {
  const q = (document.getElementById('searchBooking')?.value || '').toLowerCase();
  const arr = bookings.map((b,i) => ({...b,i})).filter(b => b.customer.toLowerCase().includes(q)).sort((a,b) => (`${a.date}${a.time}`).localeCompare(`${b.date}${b.time}`));
  document.getElementById('bookingTable').innerHTML = arr.length ? arr.map(b => {
    const remain = Math.max(0, b.total - b.paid);
    const status = remain <= 0 ? 'Lunas' : b.paid > 0 ? 'DP' : 'Belum Bayar';
    return `<tr><td><b>${escapeHTML(b.code)}</b></td><td>${escapeHTML(b.customer)}<br><small>${escapeHTML(b.note || '')}</small></td><td>${escapeHTML(b.packageName)}</td><td>${escapeHTML(b.date)}</td><td>${escapeHTML(b.time)}</td><td>${escapeHTML(b.location || '-')}</td><td>${rupiah(b.total)}</td><td>${rupiah(b.paid)}</td><td>${rupiah(remain)}</td><td><span class="badge ${remain<=0?'green':b.paid>0?'yellow':'red'}">${status}</span></td><td><div class="actions"><button class="btn-light" onclick="openPayment(${b.i})">Bayar</button><button class="btn-danger" onclick="deleteBooking(${b.i})">Hapus</button></div></td></tr>`;
  }).join('') : '<tr><td colspan="11" class="empty">Belum ada data booking.</td></tr>';
}
function renderPayments() {
  document.getElementById('paymentTable').innerHTML = bookings.length ? bookings.map((b,i) => { const r=Math.max(0,b.total-b.paid); return `<tr><td>${escapeHTML(b.code)}</td><td>${escapeHTML(b.customer)}</td><td>${rupiah(b.total)}</td><td>${rupiah(b.paid)}</td><td>${rupiah(r)}</td><td><span class="badge ${r<=0?'green':b.paid?'yellow':'red'}">${r<=0?'Lunas':b.paid?'DP':'Belum Bayar'}</span></td><td><button class="btn btn-light" onclick="openPayment(${i})">Tambah Bayar</button></td></tr>`; }).join('') : '<tr><td colspan="7" class="empty">Belum ada transaksi pembayaran.</td></tr>';
}
function renderExpenses() {
  document.getElementById('expenseTable').innerHTML = expenses.length ? expenses.map((x,i) => `<tr><td>${escapeHTML(x.transaction_date || x.date)}</td><td><span class="badge pink">${escapeHTML(x.category || 'Lainnya')}</span></td><td>${escapeHTML(x.description || '-')}</td><td>${rupiah(x.amount)}</td><td><button class="btn btn-danger" onclick="deleteExpense(${i})">Hapus</button></td></tr>`).join('') : '<tr><td colspan="5" class="empty">Belum ada pengeluaran.</td></tr>';
}
function renderDashboard() {
  const revenue=bookings.filter(b=>b.status!=='Dibatalkan').reduce((s,b)=>s+b.total,0), paid=bookings.reduce((s,b)=>s+b.paid,0), expense=expenses.reduce((s,x)=>s+Number(x.amount||0),0);
  const receivable=Math.max(0,revenue-paid), profit=revenue-expense;
  document.getElementById('dBooking').textContent=bookings.length;
  document.getElementById('dUnpaid').textContent=bookings.filter(b=>b.paid<b.total&&b.status!=='Dibatalkan').length;
  document.getElementById('dRevenue').textContent=rupiah(revenue); document.getElementById('dProfit').textContent=rupiah(profit);
  document.getElementById('dBill').textContent=rupiah(revenue); document.getElementById('dPaid').textContent=rupiah(paid); document.getElementById('dReceivable').textContent=rupiah(receivable); document.getElementById('dExpense').textContent=rupiah(expense);
  const upcoming=bookings.filter(b=>b.date>=todayStr()&&b.status!=='Dibatalkan').sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).slice(0,5);
  document.getElementById('upcoming').innerHTML=upcoming.length?upcoming.map(b=>`<div style="padding:11px 0;border-bottom:1px solid #f3e5eb;display:flex;justify-content:space-between;gap:10px"><div><b>${escapeHTML(b.customer)}</b><div style="font-size:12px;color:#907783">${escapeHTML(b.date)} • ${escapeHTML(b.time)} • ${escapeHTML(b.location||'Lokasi belum diisi')}</div></div><span class="badge pink">${escapeHTML(b.packageName)}</span></div>`).join(''):'<div class="empty">Belum ada jadwal mendatang.</div>';
}
function renderReports() {
  const active=bookings.filter(b=>b.status!=='Dibatalkan'), revenue=active.reduce((s,b)=>s+b.total,0), paid=bookings.reduce((s,b)=>s+b.paid,0), expense=expenses.reduce((s,x)=>s+Number(x.amount||0),0);
  const receivable=Math.max(0,revenue-paid), profit=revenue-expense, margin=revenue?(profit/revenue*100):0;
  document.getElementById('rRevenue').textContent=rupiah(revenue); document.getElementById('rPaid').textContent=rupiah(paid); document.getElementById('rExpense').textContent=rupiah(expense); document.getElementById('rProfit').textContent=rupiah(profit);
  document.getElementById('rBill').textContent=rupiah(revenue); document.getElementById('rPaid2').textContent=rupiah(paid); document.getElementById('rReceivable').textContent=rupiah(receivable); document.getElementById('rExpense2').textContent=rupiah(expense); document.getElementById('rProfit2').textContent=rupiah(profit); document.getElementById('rMargin').textContent=margin.toFixed(1)+'%';
  document.getElementById('rBooking').textContent=bookings.length; document.getElementById('rLunas').textContent=active.filter(b=>b.paid>=b.total).length; document.getElementById('rUnpaid').textContent=active.filter(b=>b.paid<b.total).length;
  document.getElementById('reportBookingTable').innerHTML=bookings.length?bookings.map(b=>{const r=Math.max(0,b.total-b.paid);return `<tr><td><b>${escapeHTML(b.code)}</b></td><td>${escapeHTML(b.customer)}</td><td>${escapeHTML(b.packageName)}</td><td>${rupiah(b.total)}</td><td>${rupiah(b.paid)}</td><td>${rupiah(r)}</td><td><span class="badge ${r<=0?'green':b.paid?'yellow':'red'}">${r<=0?'Lunas':b.paid?'DP':'Belum Bayar'}</span></td></tr>`;}).join(''):'<tr><td colspan="7" class="empty">Belum ada data booking.</td></tr>';
}
function openPayment(i) {
  const b=bookings[i]; if(!b) return;
  document.getElementById('payIndex').value=i; document.getElementById('payCustomer').value=b.customer;
  document.getElementById('payTotal').value=`${rupiah(b.total)} | Sudah dibayar ${rupiah(b.paid)} | Sisa ${rupiah(Math.max(0,b.total-b.paid))}`;
  document.getElementById('payAmount').value=''; document.getElementById('payAmount').max=Math.max(0,b.total-b.paid); openModal('paymentModal');
}
async function deleteBooking(i) { const b=bookings[i]; if(!b||!confirm(`Hapus booking ${b.code}?`)) return; try { await api(`/bookings/${encodeURIComponent(b.id)}`,{method:'DELETE'}); await loadData(); } catch(err) { notify(`Booking gagal dihapus: ${err.message}`); } }
async function deletePackage(i) { const p=packages[i]; if(!p||!confirm(`Hapus paket ${p.name}?`)) return; try { await api(`/packages/${encodeURIComponent(p.id)}`,{method:'DELETE'}); await loadData(); } catch(err) { notify(`Paket gagal dihapus: ${err.message}`); } }
async function deleteExpense(i) { const x=expenses[i]; if(!x||!confirm('Hapus pengeluaran ini?')) return; try { await api(`/expenses/${encodeURIComponent(x.id)}`,{method:'DELETE'}); await loadData(); } catch(err) { notify(`Pengeluaran gagal dihapus: ${err.message}`); } }
function renderAll() { renderPackages(); renderBookings(); renderPayments(); renderExpenses(); renderDashboard(); renderReports(); }
loadData();
