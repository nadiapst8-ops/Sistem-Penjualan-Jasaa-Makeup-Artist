'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const PORT = Number(process.env.PORT || 3000);
const SUPABASE_URL = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const FRONTEND_DIR = path.resolve(__dirname, '../frontend');

function send(res, status, data, headers = {}) {
  res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'GET,POST,DELETE,OPTIONS', 'Access-Control-Allow-Headers':'Content-Type', ...headers });
  res.end(JSON.stringify(data));
}
function sendText(res, status, content, type) {
  res.writeHead(status, { 'Content-Type':type, 'X-Content-Type-Options':'nosniff' }); res.end(content);
}
async function readBody(req) {
  let raw=''; for await (const chunk of req) { raw += chunk; if (raw.length > 1_000_000) throw new Error('Ukuran data terlalu besar.'); }
  if (!raw) return {}; try { return JSON.parse(raw); } catch { throw new Error('Format JSON tidak valid.'); }
}
function requireConfig() {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) throw new Error('Konfigurasi belum lengkap. Atur SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY sebagai environment variable.');
}
async function db(table, { method='GET', query='', body, prefer } = {}) {
  requireConfig();
  const url = `${SUPABASE_URL}/rest/v1/${table}${query ? `?${query}` : ''}`;
  const headers = { apikey:SUPABASE_SERVICE_ROLE_KEY, Authorization:`Bearer ${SUPABASE_SERVICE_ROLE_KEY}`, 'Content-Type':'application/json' };
  if (prefer) headers.Prefer = prefer;
  const response = await fetch(url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await response.text();
  let result; try { result = text ? JSON.parse(text) : null; } catch { result = text; }
  if (!response.ok) throw new Error(result?.message || result?.hint || `Supabase mengembalikan status ${response.status}.`);
  return result;
}
const enc = v => encodeURIComponent(String(v));
function money(n) { const x=Number(n); if (!Number.isFinite(x) || x <= 0) throw new Error('Nominal harus lebih besar dari 0.'); return x; }
function requiredString(v, label) { const s=String(v ?? '').trim(); if (!s) throw new Error(`${label} wajib diisi.`); return s; }
async function allPayments(type) { return await db('payments',{query:`select=*&transaction_type=eq.${type}&order=transaction_date.desc,created_at.desc`}) || []; }
async function initData() {
  const [packagesRaw, bookingsRaw, paymentsRaw, expensesRaw] = await Promise.all([
    db('packages',{query:'select=*&active=eq.true&order=created_at.asc'}),
    db('bookings',{query:'select=*,customer:customers(name),package:packages(name,price)&order=booking_date.desc,booking_time.desc'}),
    allPayments('payment'), allPayments('expense')
  ]);
  const paidByBooking = new Map();
  for (const p of paymentsRaw) paidByBooking.set(p.booking_id,(paidByBooking.get(p.booking_id)||0)+Number(p.amount));
  const bookings = bookingsRaw.map(b=>({
    ...b, customer_name:b.customer?.name || 'Customer', package_name:b.package?.name || '-',
    paid:paidByBooking.get(b.id)||0
  }));
  return { packages:packagesRaw, bookings, payments:paymentsRaw, expenses:expensesRaw };
}
async function routeApi(req,res,url) {
  if (req.method==='OPTIONS') { res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,DELETE,OPTIONS','Access-Control-Allow-Headers':'Content-Type'}); return res.end(); }
  const p=url.pathname;
  if (req.method==='GET' && p==='/api/health') return send(res,200,{ok:true,service:'GlowUp MUA API'});
  if (req.method==='GET' && p==='/api/init') return send(res,200,await initData());
  if (req.method==='POST' && p==='/api/packages') {
    const b=await readBody(req), name=requiredString(b.name,'Nama paket'), price=Number(b.price);
    if (!Number.isFinite(price)||price<0) throw new Error('Harga paket tidak valid.');
    const rows=await db('packages',{method:'POST',query:'select=*',prefer:'return=representation',body:{name,price,facilities:String(b.facilities||''),active:true}});
    return send(res,201,rows[0]);
  }
  let match=p.match(/^\/api\/packages\/([^/]+)$/);
  if (req.method==='DELETE' && match) {
    const id=decodeURIComponent(match[1]);
    const used=await db('bookings',{query:`select=id&package_id=eq.${enc(id)}&limit=1`});
    if (used.length) throw new Error('Paket sudah digunakan pada booking. Paket tidak bisa dihapus.');
    await db('packages',{method:'PATCH',query:`id=eq.${enc(id)}`,body:{active:false},prefer:'return=minimal'});
    return send(res,200,{ok:true});
  }
  if (req.method==='POST' && p==='/api/bookings') {
    const b=await readBody(req), customer=requiredString(b.customer,'Nama customer'), packageId=requiredString(b.package_id,'Paket');
    requiredString(b.booking_date,'Tanggal booking'); requiredString(b.booking_time,'Jam booking');
    const packRows=await db('packages',{query:`select=id,price&active=eq.true&id=eq.${enc(packageId)}&limit=1`});
    if (!packRows.length) throw new Error('Paket makeup tidak ditemukan.');
    const total=Number(packRows[0].price), dp=Number(b.dp||0);
    if (!Number.isFinite(dp)||dp<0||dp>total) throw new Error('DP tidak valid.');
    let custRows=await db('customers',{query:`select=id&name=eq.${enc(customer)}&limit=1`});
    let customerId=custRows[0]?.id;
    if (!customerId) { const created=await db('customers',{method:'POST',query:'select=id',prefer:'return=representation',body:{name:customer}}); customerId=created[0].id; }
    const code='BK'+Date.now().toString().slice(-8);
    const created=await db('bookings',{method:'POST',query:'select=*',prefer:'return=representation',body:{code,customer_id:customerId,package_id:packageId,booking_date:b.booking_date,booking_time:b.booking_time,location:String(b.location||''),total,status:b.status||'Booking',note:String(b.note||'')}});
    if (dp>0) await db('payments',{method:'POST',query:'select=id',prefer:'return=representation',body:{booking_id:created[0].id,transaction_type:'payment',amount:dp,transaction_date:new Date().toISOString().slice(0,10),method:'DP',description:'Pembayaran awal / DP'}});
    return send(res,201,{ok:true,booking:created[0]});
  }
  match=p.match(/^\/api\/bookings\/([^/]+)$/);
  if (req.method==='DELETE' && match) {
    await db('bookings',{method:'DELETE',query:`id=eq.${enc(decodeURIComponent(match[1]))}`});
    return send(res,200,{ok:true});
  }
  if (req.method==='POST' && p==='/api/payments') {
    const b=await readBody(req), bookingId=requiredString(b.booking_id,'Booking'), amount=money(b.amount);
    const bookingRows=await db('bookings',{query:`select=id,total,status& id=eq.${enc(bookingId)}&limit=1`.replace('& id=','&id=')});
    if (!bookingRows.length) throw new Error('Booking tidak ditemukan.');
    const existing=await db('payments',{query:`select=amount&booking_id=eq.${enc(bookingId)}&transaction_type=eq.payment`});
    const paid=existing.reduce((s,x)=>s+Number(x.amount),0), remaining=Number(bookingRows[0].total)-paid;
    if (amount>remaining) throw new Error(`Pembayaran melebihi sisa tagihan (${remaining}).`);
    const result=await db('payments',{method:'POST',query:'select=*',prefer:'return=representation',body:{booking_id:bookingId,transaction_type:'payment',amount,transaction_date:b.date||new Date().toISOString().slice(0,10),method:String(b.method||'Cash'),description:'Pembayaran booking'}});
    if (paid+amount>=Number(bookingRows[0].total)) await db('bookings',{method:'PATCH',query:`id=eq.${enc(bookingId)}`,body:{status:'Selesai'},prefer:'return=minimal'});
    return send(res,201,result[0]);
  }
  if (req.method==='POST' && p==='/api/expenses') {
    const b=await readBody(req), amount=money(b.amount), date=requiredString(b.date,'Tanggal pengeluaran');
    const result=await db('payments',{method:'POST',query:'select=*',prefer:'return=representation',body:{booking_id:null,transaction_type:'expense',amount,transaction_date:date,category:String(b.category||'Lainnya'),description:requiredString(b.description,'Keterangan pengeluaran')}});
    return send(res,201,result[0]);
  }
  match=p.match(/^\/api\/expenses\/([^/]+)$/);
  if (req.method==='DELETE' && match) {
    await db('payments',{method:'DELETE',query:`id=eq.${enc(decodeURIComponent(match[1]))}&transaction_type=eq.expense`});
    return send(res,200,{ok:true});
  }
  return send(res,404,{error:'Endpoint tidak ditemukan.'});
}
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.sql':'text/plain; charset=utf-8'};
function serveStatic(req,res,url) {
  let pathname=decodeURIComponent(url.pathname);
  if (pathname==='/') pathname='/index.html';
  const file=path.resolve(FRONTEND_DIR,'.'+pathname);
  if (!file.startsWith(FRONTEND_DIR+path.sep) && file!==path.join(FRONTEND_DIR,'index.html')) return sendText(res,403,'Forbidden','text/plain; charset=utf-8');
  fs.readFile(file,(err,content)=>{ if(err) return sendText(res,404,'File tidak ditemukan','text/plain; charset=utf-8'); sendText(res,200,content,mime[path.extname(file)]||'application/octet-stream'); });
}
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  try { if(url.pathname.startsWith('/api/')) await routeApi(req,res,url); else serveStatic(req,res,url); }
  catch(err) { console.error(err); const status=/wajib diisi|tidak valid|melebihi|tidak ditemukan|tidak bisa dihapus|sudah digunakan/i.test(err.message)?400:500; send(res,status,{error:err.message||'Terjadi kesalahan.'}); }
});
server.listen(PORT,()=>console.log(`GlowUp MUA berjalan di http://localhost:${PORT}`));
