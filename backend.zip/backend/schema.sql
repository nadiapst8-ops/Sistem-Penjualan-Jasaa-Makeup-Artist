-- GlowUp MUA: skema Supabase/PostgreSQL (4 entitas utama)
-- Jalankan seluruh file ini di Supabase Dashboard > SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  created_at timestamptz not null default now()
);
create index if not exists customers_name_idx on public.customers (lower(name));

create table if not exists public.packages (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  price numeric(14,2) not null check (price >= 0),
  facilities text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  customer_id uuid not null references public.customers(id) on delete restrict,
  package_id uuid not null references public.packages(id) on delete restrict,
  booking_date date not null,
  booking_time time not null,
  location text,
  total numeric(14,2) not null check (total >= 0),
  status text not null default 'Booking' check (status in ('Booking','Confirmed','Selesai','Dibatalkan')),
  note text,
  created_at timestamptz not null default now()
);
create index if not exists bookings_date_idx on public.bookings (booking_date, booking_time);

-- Tabel transaksi mencatat pembayaran booking maupun pengeluaran usaha.
-- transaction_type='payment' adalah uang masuk; 'expense' adalah uang keluar.
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings(id) on delete cascade,
  transaction_type text not null check (transaction_type in ('payment','expense')),
  amount numeric(14,2) not null check (amount > 0),
  transaction_date date not null default current_date,
  method text,
  category text,
  description text,
  created_at timestamptz not null default now(),
  constraint payment_booking_required check (
    (transaction_type = 'payment' and booking_id is not null) or
    (transaction_type = 'expense' and booking_id is null)
  )
);
create index if not exists payments_booking_idx on public.payments (booking_id);
create index if not exists payments_date_idx on public.payments (transaction_date);

insert into public.packages (name, price, facilities) values
 ('Makeup Wisuda', 250000, 'Makeup wisuda, hairdo, touch up'),
 ('Makeup Wedding', 1500000, 'Makeup pengantin, hairdo, touch up'),
 ('Makeup Pentas', 350000, 'Makeup panggung, hairdo sederhana'),
 ('Makeup Lamaran', 600000, 'Makeup lamaran, hairdo, touch up'),
 ('Makeup Photoshoot', 450000, 'Makeup photoshoot, hairdo'),
 ('Makeup Party/Event', 400000, 'Makeup event, simple hairdo')
on conflict (name) do nothing;

-- Untuk tugas lokal, app.js memakai service-role key di sisi backend.
-- Jangan pernah memasukkan service-role key ke frontend atau mengunggahnya ke GitHub.
