-- OPTIONAL DATA DEMO UNTUK PRESENTASI / UJI COBA
-- Jalankan file ini SETELAH schema.sql. Data ini contoh, bukan data transaksi asli.
-- Tetap menggunakan 4 tabel utama: customers, packages, bookings, payments.

insert into public.customers (name, phone) values
 ('Nana Demo','081234560001'),
 ('Alya Demo','081234560002'),
 ('Putri Demo','081234560003'),
 ('Citra Demo','081234560004'),
 ('Dinda Demo','081234560005')
on conflict do nothing;

insert into public.bookings (code, customer_id, package_id, booking_date, booking_time, location, total, status, note)
select v.code, c.id, p.id, v.booking_date::date, v.booking_time::time, v.location, p.price, v.status, v.note
from (values
 ('BKDEMO001','Nana Demo','Makeup Photoshoot','2026-09-24','08:00','Tembalang','Selesai','Korean makeup'),
 ('BKDEMO002','Alya Demo','Makeup Wisuda','2026-10-15','09:00','Undip Tembalang','Confirmed','Soft glam'),
 ('BKDEMO003','Putri Demo','Makeup Lamaran','2026-10-18','10:00','Banyumanik','Confirmed','Natural look'),
 ('BKDEMO004','Citra Demo','Makeup Party/Event','2026-10-22','16:00','Pedurungan','Booking','Elegant makeup'),
 ('BKDEMO005','Dinda Demo','Makeup Wedding','2026-11-07','05:00','Semarang Barat','Confirmed','Bridal makeup'),
 ('BKDEMO006','Alya Demo','Makeup Pentas','2026-11-12','13:00','Kampus Undip','Booking','Stage makeup')
) as v(code, customer_name, package_name, booking_date, booking_time, location, status, note)
join public.customers c on c.name=v.customer_name
join public.packages p on p.name=v.package_name
on conflict (code) do nothing;

insert into public.payments (booking_id, transaction_type, amount, transaction_date, method, category, description)
select b.id, v.transaction_type, v.amount, v.transaction_date::date, v.method, v.category, v.description
from (values
 ('BKDEMO001','payment',200000,'2026-09-20','Transfer',null,'DP booking photoshoot'),
 ('BKDEMO001','payment',250000,'2026-09-24','QRIS',null,'Pelunasan booking photoshoot'),
 ('BKDEMO002','payment',100000,'2026-10-01','Transfer',null,'DP booking wisuda'),
 ('BKDEMO003','payment',200000,'2026-10-05','Cash',null,'DP booking lamaran'),
 ('BKDEMO004','payment',100000,'2026-10-08','QRIS',null,'DP booking event'),
 ('BKDEMO005','payment',500000,'2026-10-09','Transfer',null,'DP booking wedding'),
 ('BKDEMO006','payment',100000,'2026-10-10','Cash',null,'DP booking pentas'),
 (null,'expense',85000,'2026-10-01',null,'Makeup Supplies','Beli foundation dan setting spray'),
 (null,'expense',45000,'2026-10-03',null,'Transportasi','Transport booking customer'),
 (null,'expense',120000,'2026-10-06',null,'Skincare','Restock skincare dan kapas'),
 (null,'expense',175000,'2026-10-09',null,'Peralatan','Beli brush makeup')
) as v(code, transaction_type, amount, transaction_date, method, category, description)
left join public.bookings b on b.code=v.code
where (v.code is null or b.id is not null)
  and not exists (
    select 1 from public.payments x
    where x.transaction_type=v.transaction_type
      and x.transaction_date=v.transaction_date::date
      and x.amount=v.amount
      and coalesce(x.description,'')=coalesce(v.description,'')
  );
